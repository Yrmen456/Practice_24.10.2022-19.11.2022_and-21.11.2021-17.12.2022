<?php 

include "conect.php";
    
if($_POST["table"]=="user"){
    $loginUser = $_POST["name"];
    $loginPass = $_POST["password"];
    $sql = "SELECT * FROM users where login = '$loginUser' and password ='$loginPass'";
        $statement = $pdo->prepare($sql);
        $statement->execute();  
        $rows = [];
        $num = 0;
        while($row = $statement->fetch())
        {
            $rows[] = $row;
            $num=$num+1;
        }
        $arr = array('otvet1' =>  "otvet11",
            'otvet2' =>  "otvet2",
            'otvet3' =>  "otvet3"
            );
    // echo json_encode($rows);
    echo json_encode($rows);
    return;        
}
    
if($_POST["table"]=="user2"){
    $loginUser = $_POST["name"];
    $loginPass = $_POST["password"];
    $sql = "SELECT * FROM users where login = '$loginUser' and password ='$loginPass'";
        $statement = $pdo->prepare($sql);
        $statement->execute();  
        $rows = [];
        $num = 0;
        while($row = $statement->fetch())
        {
            $rows[] = $row;
            $num=$num+1;
        }
        $arr = array('otvet1' =>  "otvet11",
            'otvet2' =>  "otvet2",
            'otvet3' =>  "otvet3"
            );
    // echo json_encode($rows);
    echo json_encode($rows);
    return;        
}

echo "error";
?>