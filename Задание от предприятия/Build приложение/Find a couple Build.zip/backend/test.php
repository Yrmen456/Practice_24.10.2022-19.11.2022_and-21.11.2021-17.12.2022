<?php 

// include "card_game_conect.php";
// if($sybd = 1){
   
//         $Id_user = $_POST["user"];
//         $Id_level = $_POST["level"];
//         $Datetime = $_POST["datetime"];
//         $time = $_POST["time"];
//         $status = $_POST["status"];
//         if("".$status == "false"){
//             $status = 0;
//         }else{
//             $status = 1;   
//         }

//         $sql = "INSERT INTO `INSERT INTO `history_game`( `user`, `level`, `date`, `time`, `status`) VALUES ('1','1','2003:12:12 12:12:12','10:12:12','1')";
//             $statement = $pdo->prepare($sql);
//             $statement->execute();
//             $id = $pdo->lastInsertId();
//             if($statement->rowCount() > 0) {
//                 // запрос удался
                 
//             } else {
//                     // запрос по каким-то причинам не выполнен 
//                     echo "yt";
//             }
//         // echo json_encode($rows);
//         echo $id;
//         return;        
   
// }

function foo()
{
    echo "asdsad";
}


?>