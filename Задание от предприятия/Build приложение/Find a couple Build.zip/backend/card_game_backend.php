<?php 

include "card_game_conect.php";
if($sybd = 1){
    if($_POST["table"]=="user"){
        $loginUser = $_POST["name"];
        $loginPass = $_POST["password"];
        $sql = "SELECT * FROM users where email = N'$loginUser' and password =N'$loginPass'";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
            $rows = [];
            $num = 0;
            while($row = $statement->fetch())
            {
                $rows[] = $row;
                $num=$num+1;
            }
        // echo json_encode($rows);
        echo json_encode($rows);
        return;        
    }
    if($_POST["table"]=="CheckPassword"){
        $loginUser = $_POST["name"];
        $sql = "SELECT * FROM users where email = N'$loginUser'";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
            if($statement->rowCount() > 0) {
                // запрос удался
                echo "1";
            } else {
                // запрос по каким-то причинам не выполнен 
                echo "0";
            }
      
        return;        
    }
    if($_POST["table"]=="TrainingComplete"){
        $Id_user = $_POST["id"];
        $arr = array();
        try
        {
            $sql = "UPDATE `users` SET `training`=N'1' WHERE id = $Id_user;";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
           
            if($statement->rowCount() > 0) {
                // запрос удался
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Запись успешно изменена",
                    'information' => "",
                    );
            } else {
                // запрос по каким-то причинам не выполнен 
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Не удалось изменить запись",
                    'information' => "",
                    );
            }
        }
        catch(Exception $e) {
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Что то пошло не так",
                    'information' => ""+$e->getMessage(),
                    );
             
        }
        
   

        echo json_encode($arr);

        return;        
    }
    if($_POST["table"]=="RefreshPassword"){
        $loginUser = $_POST["name"];
        $NewPaasword = $_POST["password"];
        $arr = array();
        try
        {
            $sql = "UPDATE `users` SET `password`=N'$NewPaasword' WHERE email = N'$loginUser';";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
           
            if($statement->rowCount() > 0) {
                // запрос удался
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Пароль успешно изменен",
                    'information' => "",
                    );
            } else {
                // запрос по каким-то причинам не выполнен 
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Не удалось изменить пароль",
                    'information' => "",
                    );
            }
        }
        catch(Exception $e) {
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Что то пошло не так",
                    'information' => ""+$e->getMessage(),
                    );
             
        }
        
   

        echo json_encode($arr);

        return;        
    }
        
    if($_POST["table"]=="levels"){
        $Id_User = $_POST["id"];
        $sql = "SELECT levels.id, levels.name , levels.position , Min(time) as time, CASE WHEN history_game.status = 1 THEN 'true' ELSE 'false' END AS status FROM `levels` Left JOIN history_game history_game on history_game.level = levels.id and history_game.status = 1 and history_game.user = $Id_User  WHERE 1 GROUP by levels.id, history_game.status ORDER by levels.position;";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
            $rows = [];
            $num = 0;
            while($row = $statement->fetch())
            {
                $rows[] = $row;
                $num=$num+1;
            }
    
        //echo json_encode($rows);
        echo json_encode($rows);
        return;        
    }
    if($_POST["table"]=="cards_level"){
        $levels = $_POST["level"];
        $sql = "SELECT cards.id, cards.level, cards.text, cards.connection, levels.name FROM `cards`, `levels` WHERE cards.level = '$levels' and levels.id = '$levels';";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
            $rows = [];
            $num = 0;
            while($row = $statement->fetch())
            {
                $rows[] = $row;
                $num=$num+1;
            }
            
        // echo json_encode($rows);
        echo json_encode($rows);
        return;        
    }

    if($_POST["table"]=="testic"){

        $arr = array(
        'status' =>  true,
        'answer' =>  "otvet2",
        'information' => "sdddd",
        );
    
        // echo json_encode($rows);
        echo json_encode($arr);
        return;        
    }   
    if($_POST["table"]=="GameStart"){
        $Id_user = $_POST["user"];
        $Id_level = $_POST["level"];
        $DateTimeStart = $_POST["datetimestart"];
        $arr = array();
        try
        {
            $sql = "INSERT INTO `history_game`(`user`, `level`, `date`, `status`) VALUES ('$Id_user ',' $Id_level',' $DateTimeStart','0');";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
            $id = $pdo->lastInsertId();
            if($statement->rowCount() > 0) {
                // запрос удался
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Успешно записана",
                    'information' => "".$id,
                    );
            } else {
                // запрос по каким-то причинам не выполнен 
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Запись не записалась",
                    'information' => "".$id,
                    );
            }
        }
        catch(Exception $e) {
                $arr = array(
                    'status' =>  false,
                    'answer' =>  "Что то пошло не так",
                    'information' => "".$e->getMessage(),
                    );
             
        }
        
   

        echo json_encode($arr);

        return;        
    }
    if($_POST["table"]=="GameWin"){
        $Id_History_Game = $_POST["id_game"];
        $Time = $_POST["time"];
        $arr = array();
        try
        {
            $sql = "UPDATE `history_game` SET `time`='$Time',`status`='1' WHERE id =  $Id_History_Game";
            $statement = $pdo->prepare($sql);
            $statement->execute();  
           
            if($statement->rowCount() > 0) {
                // запрос удался
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Успешно обновлена",
                    'information' => "",
                    );
            } else {
                // запрос по каким-то причинам не выполнен 
                $arr = array(
                    'status' =>  true,
                    'answer' =>  "Запись не обновлена",
                    'information' => "",
                    );
            }
        }
        catch(Exception $e) {
                $arr = array(
                    'status' =>  false,
                    'answer' =>  "Что то пошло не так",
                    'information' => "".$e->getMessage(),
                    );
             
        }
        
   

        echo json_encode($arr);

        return;        
    }
    if($_POST["table"]=="Add_"){

        $arr = array(
        'status' =>  true,
        'answer' =>  "otvet2",
        'information' => "sdddd",
        );
    
        // echo json_encode($rows);
        echo json_encode($arr);
        return;        
    }
    echo "error";
}else{

}
function foo()
{
    echo "asdsad";
}
?>