<?php

$sybd = 1;
if($sybd ==1){
    try {
        //$pdo = new PDO("mysql:host=localhost;dbname=cards_master", "root", "");
        $pdo = new PDO("mysql:host=localhost;dbname=a0757221_Cards_Master", "a0757221_root", "root");
    } catch (PDOException $e) {
        echo "error";
        return;
    }
}else{
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=cards_master", "root", "");
        
    } catch (PDOException $e) {
        echo "error";
        return;
    }
}

?>