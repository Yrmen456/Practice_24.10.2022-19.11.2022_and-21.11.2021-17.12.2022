<?php

$sybd = 1;
if($sybd ==1){
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=cards_master", "root", "");
        //$pdo = new PDO("mysql:host=localhost;dbname=a0748696_Cards_Master", "a0748696_root", "root");
    } catch (PDOException $e) {
        echo "error";
        return;
    }
}else{
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=cards_master", "root", "");
        
    } catch (PDOException $e) {
        echo "error";
        return;
    }
}

?>