<?php
//$pdo = new PDO("mysql:host=localhost;dbname=a0722395_reader_books", "a0722395_root", "root");

try {
    $pdo = new PDO("mysql:host=localhost;dbname=users_unity", "root", "");
    
} catch (PDOException $e) {
	echo "".$e;
    return;
}
?>